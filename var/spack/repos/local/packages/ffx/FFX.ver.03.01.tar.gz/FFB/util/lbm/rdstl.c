#include <stdio.h>
#include <string.h>
#include <stdarg.h>

void rdstl_( int *, int *, int *, int *, char *, 
             int *, float *, 
	     int *);

void rdstl_( int *imode, int *IUT0, int *IUT6,  int *IUNIT, char *FILEd, 
	     int *ne,    float *coord, 
	     int *ierr)
{
  int i,j,ie,nint;
  int ibuf;
  FILE *fp; 
  *ierr=0 ; 

  /*LOCAL ENTRY FOR BUFFER */ 
  char  FILENM[61]   = " "       ;
  char  cbuf  [80]   = " "       ;
  float fbuf  [12]   ;

  i=0;while( *(FILEd+i) != ' ' && i<61){*(FILENM+i)=*(FILEd+i);i++;}

  /* printf("%s    \n",FILENM); */

  if( ( fp = fopen(FILENM,"r") ) == NULL){*ierr = 101;return; }

  fread(&cbuf,80,1,fp);  /*  printf("Header      : %s \n",cbuf); */
  fread(&ibuf, 4,1,fp);  /*  printf("Num. of Tri.: %d \n",ibuf); */
  *ne=ibuf;
  if(*imode==1){
    fclose(fp);
    return;
  }

  nint= *ne/100 ;
  for(ie=0;ie<*ne;ie++){
    fread(&fbuf,4,12,fp);  
    if(ie%nint==0){
      /*
      printf("ie = %d ne= %d ",ie, ne); 
      printf("%13.5f %13.5f %13.5f \n",fbuf[0],fbuf[1],fbuf[2]); 
      printf("%13.5f %13.5f %13.5f ",fbuf[3],fbuf[4],fbuf[5]); 
      printf("%13.5f %13.5f %13.5f ",fbuf[6],fbuf[7],fbuf[8]); 
      printf("%13.5f %13.5f %13.5f \n",fbuf[9],fbuf[10],fbuf[11]); 
      */
    }
    for(j=0;j<12;j++){
      *(coord+j+12*ie)=fbuf[j];
    }
    fread(&cbuf,2,1,fp);  
  } /* for(ie=0;ie<ne;ie++) */

}
