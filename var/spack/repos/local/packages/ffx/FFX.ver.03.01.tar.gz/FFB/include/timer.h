C
      integer*4 nddcom2b, nddcom2, nddcom2a
      real*8    tddcom2b, tddcom2, tddcom2a
C
      integer*4 nddcomxb, nddcomx, nddcomxa
      real*8    tddcomxb, tddcomx, tddcomxa
C
      integer*4 nvel3d1
      real*8    tvel3d1
C
      integer*4 ngrad3x
      real*8    tgrad3x
C
      integer*4 ncalax3
      real*8    tcalax3
C      
      common / TIMER /
     *     nddcom2b, nddcom2, nddcom2a, nddcomxb, nddcomx, nddcomxa,
     *     nvel3d1,  ngrad3x, ncalax3,
     *     tddcom2b, tddcom2, tddcom2a, tddcomxb, tddcomx, tddcomxa,
     *     tvel3d1,  tgrad3x, tcalax3
C      
      real*8 tstart, tend
