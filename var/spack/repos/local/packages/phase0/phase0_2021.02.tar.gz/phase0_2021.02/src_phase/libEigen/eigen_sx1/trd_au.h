      real(8), pointer       ::  u0_z(:),v0_z(:)
      real(8), pointer       ::  u1_z(:),v1_z(:)
      integer                ::  offset1, offset2
      integer                ::  offset3, offset4
      common  /tred_au_common/   u0_z, v0_z, u1_z, v1_z,
     &                           offset1, offset2, offset3, offset4

