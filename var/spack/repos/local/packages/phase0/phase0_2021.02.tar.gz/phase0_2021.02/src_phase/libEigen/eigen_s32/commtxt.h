!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!  for DC
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      integer          :: mpi_comm_eigen, ICTXTtoDC, MYROWtoDC,
     &                    MYCOLtoDC
      common /COMMtoDC/   mpi_comm_eigen, ICTXTtoDC, MYROWtoDC,
     &                    MYCOLtoDC
