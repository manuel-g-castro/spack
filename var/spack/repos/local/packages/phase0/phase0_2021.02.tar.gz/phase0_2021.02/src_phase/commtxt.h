!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!  for DC
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      integer          :: MPI_COMM_EIGEN, ICTXTtoDC, MYROWtoDC,&
     &                    MYCOLtoDC, NPROWtoDC, NPCOLtoDC
      common /COMMtoDC/   MPI_COMM_EIGEN, ICTXTtoDC, MYROWtoDC,&
     &                    MYCOLtoDC, NPROWtoDC, NPCOLtoDC
