typedef unsigned long ticks;
void getclkreg_(ticks *t);
