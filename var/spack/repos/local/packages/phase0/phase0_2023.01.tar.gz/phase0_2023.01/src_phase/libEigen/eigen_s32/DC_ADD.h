       REAL(8) :: flops, dgemm_time,
     &            p_time0, p_time2, p_time3, p_times, p_timez, p_timer
       common /DC_ADD/ flops, dgemm_time,
     &            p_time0, p_time2, p_time3, p_times, p_timez, p_timer
