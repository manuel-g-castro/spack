#imrcolor,lincolor��2�ʂ�̎w����@(linecolor,linecolor2)�̂����Е����g��
erange=" -erange -13,15"
#erange=" -erange 0,4"
einc="-einc 1.0"
imrfont="-imrfont Helvetica,14"
#ticsfont="-ticsfont Helvetica,10"
#imrcolor="-imrcolor #545422"
imrcolor2="-imrcolor blue"
#linecolor="-linecolor #545422"
linecolor2="-linecolor red"
imrtype="-imrtype mulliken"
-nonecross="-nonecross"
#kgrouptype="-kgrouptype Schoenflies"
withfermi="-with_fermi nfefermi.data"
numimr="-numimr 0.1"
perl ~/phase/band_symm.09.2016test/perl/band_symm.pl reduce_up.data ${erange} ${einc} ${imrfont} ${ticsfont} ${imrcolor} ${imrcolor2} ${linecolor} ${linecolor2} ${imrtype} ${nonecross} ${kgrouptype} ${withfermi} ${numimr}
echo "${erange} ${einc} ${imrfont} ${ticsfont} ${imrcolor} ${imrcolor2} ${linecolor} ${linecolor2} ${imrtype} ${nonecross} ${kgrouptype} ${withfermi} ${numimr}"
mv band_reduce.eps band_up.eps