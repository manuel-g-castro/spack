```
$ cd scf
$ mpiexec -n 2 ../../../../../bin/phase
$ cd ../band
$ ../../../../../bin/band_kpoint.pl ../../../../tools/bandkpt_fcc_xglux.in
$ mpiexec -n 2 ../../../../../bin/ekcal ne=2 nk=2
$ ../../../../../bin/band.pl nfenergy.data ../../../../tools/bandkpt_fcc_xglux.in
$ evince band_structure.eps
```
