      integer(4) :: ndim_switch
      ndim_switch=5000
